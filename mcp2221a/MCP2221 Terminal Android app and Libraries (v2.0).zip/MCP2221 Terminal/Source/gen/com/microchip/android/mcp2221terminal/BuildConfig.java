/** Automatically generated file. DO NOT MODIFY */
package com.microchip.android.mcp2221terminal;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}